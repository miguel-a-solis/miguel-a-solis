from math import pi

r = float(raw_input("Ingrese radio: "))
perimetro = 2*pi*r
area = pi*r**2
print "Su perimetro es",perimetro
print "Su area es",area

# Alternativa:
# (borrar '#' y comentar o borrar el codigo anterior)
#
# r = float(raw_input("Ingrese radio: "))
# pi = 3.14
# print "Su perimetro es",2*pi*r
# print "Su area es",pi*r**2
