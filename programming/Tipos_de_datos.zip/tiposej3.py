precio = 510
cantidad = float(raw_input("Cantidad dolares: "))
print "El equivalente corresponde a",int(round(precio*cantidad)),"pesos"
