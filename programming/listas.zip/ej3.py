def calcular_puntaje(anotaciones):
    puntos = 0
    for tiro in anotaciones:
        if tiro == "L":
            puntos += 1
        elif tiro == "D":
            puntos += 2
        elif tiro == "T":
            puntos += 3
    return puntos

def ganador_partido(anotaciones_a,anotaciones_b):
    ptos_a = calcular_puntaje(anotaciones_a)
    ptos_b = calcular_puntaje(anotaciones_b)
    if ptos_a == ptos_b:
        return "Empate"
    elif ptos_a > ptos_b:
        return "A"
    else:
        return "B"
