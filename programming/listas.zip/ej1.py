alumnos = int(raw_input("Numero alumnos: "))
mejores = int(raw_input("Numero mejores promedios: "))
promedios = []
for alumno in range(1,alumnos+1):
    suma = 0
    for prueba in range(1,3):
        nota = float(raw_input("Nota prueba "+str(prueba)+",alumno "+str(alumno)+": "))
        suma += nota
    promedios.append(suma/2)
promedios.sort()
promedios.reverse()
print "Mejores promedios: ",
for promedio in promedios[:mejores]:
    print promedio,
