def probabilidad_tsunami(mareas,umbral):
    contador = 0
    for marea in mareas:
        if marea > umbral:
            contador += 1
    return 100.0*contador/len(mareas)
