s1 = float(raw_input('Nota 1: '))
s2 = float(raw_input('Nota 2: '))
s3 = float(raw_input('Nota 3: '))
p = (s1 + s2 + s3)/3
print 'Su promedio es', round(p,1)
