n = raw_input("Ingrese un numero: ")
suma = 0
i = 0
while i < len(n):
    suma = suma + int(n[i])**2
    i = i + 1
print suma

## Alternativa (usando ciclo for)
## borrar comentarios y comentar (agregar #) o borrar codigo anterior
#
#n = raw_input("Ingrese un numero: ")
#suma = 0
#for i in range(len(n)):
#    suma = suma + int(n[i])**2
#print suma
##
## Alternativa 2:
##
#n = raw_input("Ingrese un numero: ")
#suma = 0
#for i in n:
#    suma = suma + int(i)**2
#print suma
##
## Alternativa 3:
##
#n = int(raw_input("Ingrese un numero: "))
#suma = 0
#while n != 0:
#    digito = n%10
#    suma = suma + digito**2
#    n = n/10
#print suma
