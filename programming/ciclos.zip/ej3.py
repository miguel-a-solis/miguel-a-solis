suma3 = 0
suma 7 = 0
numero = int(raw_input("Ingrese numero: "))
while numero != 0:
    digito = numero%10
    if digito == 3:
        suma3 = suma3 + 1
    elif digito == 7:
        suma7 = suma7 + 1
    numero = numero/10
print "hay",suma7,"numero 7"
print "hay",suma3,"numero 3"
