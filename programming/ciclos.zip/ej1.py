n = int(raw_input("Ingrese cantidad de numeros: "))
suma = 0
for i in range(n):
    x = float(raw_input("Ingrese numero " + str(i+1) + ": "))
    suma = suma + x
promedio = suma/n
print "El promedio es",promedio

## Alternativa (usando ciclo while)
## borrar comentarios y comentar (agregar #) o borrar codigo anterior
#
#n = int(raw_input("Ingrese cantidad de numeros: "))
#suma = 0
#i = 0
#while i < n:
#    x = float(raw_input("Ingrese numero "+ str(i+1) + ": "))
#    suma = suma + x
#    i = i+1
#promedio = suma/n
#print "El promedio es",promedio
