def distancia(p1,p2):
    if len(p1) == len(p2):
        suma = 0
        for posicion in range(len(p1)):
            suma += (p1[posicion]-p2[posicion])**2
        return suma**0.5
    else:
        return -1

def perimetro(vertices):
    total = 0
    for posicion in range(len(vertices)):
        p1 = vertices[posicion]
        p2 = vertices[(posicion+1)%len(vertices)]
        total += distancia(p1,p2)
    return total
