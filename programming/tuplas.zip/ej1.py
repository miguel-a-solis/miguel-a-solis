def distancia(p1,p2):
    if len(p1) == len(p2):
        suma = 0
        for posicion in range(len(p1)):
            suma += (p1[posicion]-p2[posicion])**2
        return suma**0.5
    else:
        return -1
