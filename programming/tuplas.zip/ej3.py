def contar_letras(palabra):
    final = []
    for posicion in range(len(palabra)):
        esta = False
        letra = palabra[posicion]
        for indice in range(len(final)):
            tupla = final[indice]
            if letra == tupla[0]:
                final[indice] = (tupla[0],tupla[1]+1)
                esta = True
        if not esta:
            final.append((letra,1))
    return final
