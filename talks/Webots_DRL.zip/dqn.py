import random
import numpy as np
from collections import deque
import tensorflow as tf
from tensorflow.keras import layers, models, optimizers, losses
from controller import Supervisor

def create_q_network(state_dim, action_dim):
    model = models.Sequential([
        layers.Input(shape=(state_dim,)),
        layers.Dense(64, activation='relu'),
        layers.Dense(64, activation='relu'),
        layers.Dense(action_dim, activation='linear')
    ])
    return model

class ReplayBuffer:
    def __init__(self, capacity=10000):
        self.buffer = deque(maxlen=capacity)

    def push(self, state, action, reward, next_state, done):
        self.buffer.append((state, action, reward, next_state, done))

    def sample(self, batch_size):
        batch = random.sample(self.buffer, batch_size)
        states, actions, rewards, next_states, dones = zip(*batch)
        return (
            np.array(states, dtype=np.float32),
            np.array(actions, dtype=np.int32),
            np.array(rewards, dtype=np.float32),
            np.array(next_states, dtype=np.float32),
            np.array(dones, dtype=np.float32)
        )

    def __len__(self):
        return len(self.buffer)

class EpuckEnv:
    def __init__(self):
        self.robot = Supervisor()
        self.timestep = int(self.robot.getBasicTimeStep())

        self.left_motor = self.robot.getDevice('left wheel motor')
        self.right_motor = self.robot.getDevice('right wheel motor')
        self.left_motor.setPosition(float('inf'))
        self.right_motor.setPosition(float('inf'))
        self.left_motor.setVelocity(0.0)
        self.right_motor.setVelocity(0.0)

        self.ps = []
        for i in range(8):
            sensor = self.robot.getDevice(f'ps{i}')
            sensor.enable(self.timestep)
            self.ps.append(sensor)

        self.robot_node = self.robot.getSelf()
        self.trans_field = self.robot_node.getField('translation')
        self.rotation_field = self.robot_node.getField('rotation')

        self.actions = {
            0: (5.0, 5.0),    # Avanzar
            1: (-2.5, 5.0),   # Girar izquierda
            2: (5.0, -2.5)    # Girar derecha
        }

    def get_sensor_readings(self):
        readings = [sensor.getValue() / 4000.0 for sensor in self.ps]
        return np.clip(readings, 0.0, 1.0)

    def reset(self):
        self.left_motor.setVelocity(0.0)
        self.right_motor.setVelocity(0.0)

        self.trans_field.setSFVec3f([0.0, 0.0, 0.0])
        self.rotation_field.setSFRotation([0.0, 1.0, 0.0, random.uniform(0, 2 * np.pi)])
        self.robot_node.resetPhysics()

        for _ in range(5):
            self.robot.step(self.timestep)

        return self.get_sensor_readings()

    def step(self, action_idx):
        v_left, v_right = self.actions[action_idx]
        self.left_motor.setVelocity(v_left)
        self.right_motor.setVelocity(v_right)

        self.robot.step(self.timestep)

        next_state = self.get_sensor_readings()
        done = max(next_state) > 0.35  # Umbral de choque
        reward = -100.0 if done else 1.0

        return next_state, reward, done

def train_dqn():
    env = EpuckEnv()

    state_dim = 8
    action_dim = 3
    gamma = 0.99
    lr = 0.001
    batch_size = 64
    memory_capacity = 10000
    episodes = 200
    max_steps_per_episode = 500

    epsilon = 1.0
    epsilon_min = 0.05
    epsilon_decay = 0.98

    q_network = create_q_network(state_dim, action_dim)
    target_network = create_q_network(state_dim, action_dim)
    target_network.set_weights(q_network.get_weights())

    optimizer = optimizers.Adam(learning_rate=lr)
    loss_fn = losses.MeanSquaredError()
    buffer = ReplayBuffer(memory_capacity)

    for episode in range(1, episodes + 1):
        state = env.reset()
        total_reward = 0

        for step in range(max_steps_per_episode):
            if random.random() < epsilon:
                action = random.randint(0, action_dim - 1)
            else:
                state_tensor = tf.convert_to_tensor([state], dtype=tf.float32)
                q_values = q_network(state_tensor)
                action = int(tf.argmax(q_values[0]))

            next_state, reward, done = env.step(action)
            buffer.push(state, action, reward, next_state, float(done))

            state = next_state
            total_reward += reward

            if len(buffer) >= batch_size:
                b_states, b_actions, b_rewards, b_next_states, b_dones = buffer.sample(batch_size)

                next_q_values = target_network(b_next_states)
                max_next_q = tf.reduce_max(next_q_values, axis=1)
                target_q = b_rewards + gamma * max_next_q * (1.0 - b_dones)

                with tf.GradientTape() as tape:
                    all_q_values = q_network(b_states)
                    action_masks = tf.one_hot(b_actions, action_dim)
                    pred_q = tf.reduce_sum(all_q_values * action_masks, axis=1)
                    loss = loss_fn(target_q, pred_q)

                grads = tape.gradient(loss, q_network.trainable_variables)
                optimizer.apply_gradients(zip(grads, q_network.trainable_variables))

            if done:
                break

        epsilon = max(epsilon_min, epsilon * epsilon_decay)

        if episode % 5 == 0:
            target_network.set_weights(q_network.get_weights())

        print(f"Episodio: {episode:3d} | Recompensa Total: {total_reward:6.1f} | Epsilon: {epsilon:.2f}")

train_dqn()