import sys
from controller import Robot

robot = Robot()
paso_tiempo = int(robot.getBasicTimeStep())

motor_izq = robot.getDevice("left wheel motor")
motor_der = robot.getDevice("right wheel motor")
motor_izq.setPosition(float('inf'))
motor_der.setPosition(float('inf'))
motor_izq.setVelocity(0.0)
motor_der.setVelocity(0.0)

# ps0: 10° a la derecha, ps1: 45° a la derecha
# ps7: 10° a la izquierda, ps6: 45° a la izquierda
ps0 = robot.getDevice("ps0")
ps1 = robot.getDevice("ps1")
ps6 = robot.getDevice("ps6")
ps7 = robot.getDevice("ps7")

ps0.enable(paso_tiempo)
ps1.enable(paso_tiempo)
ps6.enable(paso_tiempo)
ps7.enable(paso_tiempo)

velocidad = 3.0

while robot.step(paso_tiempo) != -1:
    obstaculo_derecha = ps0.getValue() > 100.0 or ps1.getValue() > 100.0
    obstaculo_izquierda = ps7.getValue() > 100.0 or ps6.getValue() > 100.0

    if obstaculo_derecha:
        vel_izq = -velocidad
        vel_der = velocidad
    elif obstaculo_izquierda:
        vel_izq = velocidad
        vel_der = -velocidad
    else:
        vel_izq = velocidad
        vel_der = velocidad

    motor_izq.setVelocity(vel_izq)
    motor_der.setVelocity(vel_der)

robot.cleanup()