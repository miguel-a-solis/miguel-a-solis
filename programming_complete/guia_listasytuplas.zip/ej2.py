precios = [ ("aceite", 2000), ("arroz", 1000), ("cafe", 1500), ("te", 300),
            ("papas fritas", 1200) ,("cocacola", 800),("leche", 650) ]
miscompras = [("arroz",1), ("papas fritas",2), ("cocacola",3), ("leche",16)]

def producto_mas_caro(precios):
    mas_caro = ""
    mayor = 0
    for nombre,monto in precios:
        if monto > mayor:
            mayor = monto
            mas_caro = nombre
    return mas_caro

def monto_total(precios,miscompras):
    total = 0
    for nombre,cantidad in miscompras:
        for producto,precio in precios:
            if nombre == producto:
                total += precio*cantidad
    return total

def alimentacion_sana(s):
    final = []
    for posicion in range(len(miscompras)):
        tupla = miscompras[posicion]
        if tupla[0] not in s:
            final.append(tupla)
    return final
