viajes = [("Enero", (("Canada", 1), ("EEUU", 2)) ),
          ("Marzo", (("Peru", 3),("Argentina", 1), ("Bolivia", 2)) ) ]

def cantidad_viajes(viajes,mes):
    cuenta = 0
    for nombre,tuplas in viajes:
        if nombre == mes:
            for pais,cantidad in tuplas:
                cuenta += cantidad
            return cuenta
    return -1

def imprimir_paises(viajes,lista):
    for pais in lista:
        cuenta = 0
        for mes,tuplas in viajes:
            for nombre,cantidad in tuplas:
                if nombre == pais:
                    cuenta += cantidad
        print pais,"fue visitado",cuenta,"veces en el anho"

def sin_viajes(viajes):
    meses = ["Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre",
             "Octubre","Noviembre","Diciembre"]
    final = []
    for mes in meses:
        esta = False
        for nombre,tuplas in viajes:
            if nombre == mes:
                esta = True
        if not esta:
            final.append(mes)
    return final
