polen = [ ("pino", 7), ("platanoOriental", 27), ("pasto", 1),
          ("malezas", 15),("olmo", 19), ("nogal", 10), ("olivo", 14) ]

def niveles(polen):
    bajos,medios,altos = 0,0,0
    for planta,nivel in polen:
        if nivel <= 10:
            bajos += 1
        elif nivel <= 15:
            medios += 1
        else:
            altos += 1
    return (bajos,medios,altos)
# Alternativa:
# (borrar comentarios posteriores y comentar codigo anterior
#
#def niveles(polen):
#    cuentas = [0,0,0]
#    for planta,nivel in polen:
#        if nivel <= 10:
#            cuentas[0] += 1
#        elif nivel <= 15:
#            cuentas[1] += 1
#        else:
#            cuentas[2] += 1
#    return tuple(cuentas)
