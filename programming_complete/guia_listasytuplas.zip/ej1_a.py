alumnos = int(raw_input("Cantidad de alumnos: "))
promedios = []
for alumno in range(1,alumnos+1):
    suma = 0
    nota = -1
    cuenta = 1
    nombre = raw_input("Nombre alumno "+str(alumno)+": ")
    while nota != 0:
        nota = float(raw_input("Nota "+str(cuenta)+"de "+nombre+": "))
        if nota != 0:
            suma += nota
            cuenta += 1
    promedios.append((suma/cuenta,nombre))
promedios.sort()
print promedios[-1][1],"tiene el promedio mas alto"
        
