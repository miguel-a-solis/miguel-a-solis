def probabilidad_tsunami(mareas,umbral):
    cuenta = 0
    for marea in mareas:
        if marea > umbral:
            cuenta += 1
    return 100.0*cuenta/len(mareas)

def hay_que_evacuar(mareas):
    porcentaje = probabilidad_tsunami(mareas,270)
    if porcentaje > 32:
        return True
    return False

# Alternativa:
# (borrar comentarios posteriores y comentar codigo anterior
#
#def hay_que_evacuar(mareas):
#    return probabilidad_tsunami(mareas,270) > 32
