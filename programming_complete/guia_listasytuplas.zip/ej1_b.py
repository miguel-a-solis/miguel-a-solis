def mejor_promedio(alumnos):
    promedios = []
    for nombre,notas in alumnos:
        promedios.append((sum(notas)/len(notas),nombre))
    promedios.sort()
    return promedios[-1][1]
