inicio = raw_input("Hora de inicio: ")
fin = raw_input("Hora de fin: ")
dif_h = int(fin[:2])-int(inicio[:2])
dif_m = int(fin[3:5])-int(inicio[3:5])
dif_s = int(fin[6:])-int(inicio[6:])
if dif_h < 0 or (dif_h == 0 and dif_m < 0) or (dif_h == 0 and dif_m == 0 and dif_s <0):
    print "La hora de termino es menor a la hora de inicio"
else:
    print "Ha transcurrido",
    if dif_h != 0:
        print dif_h,"hora",
    if dif_m != 0:
        print dif_m,"minutos",
    if dif_s != 0:
        print dif_s,"segundos"
