numero = int(raw_input("Ingrese numero: "))
if numero < 0:
    print "El numero es negativo"
elif numero == 0:
    print "El numero es cero"
else:
    print "El numero es positivo"
