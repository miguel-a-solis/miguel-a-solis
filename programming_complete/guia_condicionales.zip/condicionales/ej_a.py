n1 = float(raw_input("Ingrese n1: "))
n2 = float(raw_input("Ingrese n2: "))
if n1 > n2:
    print "n1 es mayor"
elif n1 < n2:
    print "n2 es mayor"
else:
    print "Los numeros son iguales"
