cantidad = int(raw_input("Cantidad de pasajeros: "))
hora = raw_input("Hora: ")
if 0 <= int(hora[:2]) <= 5:
    tarifa = 900
else:
    tarifa = 600
print "Debe pagar",cantidad*tarifa,"pesos"
