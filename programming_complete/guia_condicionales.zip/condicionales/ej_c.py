pedro = int(raw_input("Edad de Pedro: "))
juan = int(raw_input("Edad de Juan: "))
diego = int(raw_input("Edad de Diego: "))
if pedro == juan and juan == diego:
    print "Los tres tienen edades iguales"
elif pedro == juan:
    print "Pedro y Juan tienen la misma edad"
elif pedro == diego:
    print "Pedro y Diego tienen la misma edad"
elif juan == diego:
    print "Juan y Diego tienen la misma edad"
else:
    print "Los tres tienen edades distintas"
