binario = raw_input("Ingrese secuencia binaria")
if int(binario[0]) == 0:
    signo = 1
else:
    signo = -1
decimal = int(binario[-1])*2**0 + int(binario[-2])*2**1 + int(binario[-3])*2**2
print "El equivalente decimal con signo es",signo*decimal
