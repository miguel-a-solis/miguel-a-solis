def mcm(a,b):
    multiplo_a = a
    multiplo_b = b
    while True:
        if multiplo_a < multiplo_b:
            if multiplo_a + a == multiplo_b:
                return multiplo_b
            multiplo_a += a
        else:
            if multiplo_b + b == multiplo_a:
                return multiplo_a
            multiplo_b += b
                
            
