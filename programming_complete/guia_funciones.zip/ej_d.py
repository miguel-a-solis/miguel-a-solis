def es_primo(n):
    divisor = 2
    primo = True
    while divisor < n:
        if n%divisor == 0:
            primo = False
        divisor += 1
    return primo
