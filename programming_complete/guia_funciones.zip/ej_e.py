def mas_larga(a,b):
    letras_a = ""
    letras_b = ""
    contador_a = 0
    contador_b = 0
    while contador_a < len(a):
        if a[contador_a] not in letras_a:
            letras_a += a[contador_a]
        contador_a += 1
    while contador_b < len(b):
        if b[contador_b] not in letras_b:
            letras_b += b[contador_b]
        contador_b += 1
    if len(letras_a) > len(letras_b):
        return a
    return b
            
