def mcd(a,b): #20,50
    divisor_a = 1
    maximo = 1
    while divisor_a < a:
        if a%divisor_a == 0:
            divisor_b = 1
            while divisor_b < b:
                if b%divisor_b == 0 and divisor_a == divisor_b and divisor_a > maximo:
                    maximo = divisor_a
                divisor_b += 1
        divisor_a += 1
    return maximo
                        
            
