def invertir_digitos(n):
    largo = len(str(n))
    exponente = 0
    resultado = 0
    while n > 0:
        digito = n%10
        resultado += digito*10**(largo-exponente-1)
       n /= 10
        exponente += 1
    return resultad
#
# Alternativa 1:
# (borrar '#' y comentar o borrar el codigo anterior)
#
#def invertir_digitos(n):
#    n = str(n)
#    largo = len(n)
#    resultado = ""
#    contador = 0
#    while contador < largo:
#        resultado = n[contador] + resultado
#        contador += 1
#    return int(resultado)
#
# Alternativa 2:
# (borrar '#' y comentar o borrar el codigo anterior)
#    
#def invertir_digitos(n):
#    return int(str(n)[::-1])
