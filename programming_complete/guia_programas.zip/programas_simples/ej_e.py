dolares = float(raw_input("Cantidad dolares: "))
conversion = 510
print "El equivalente corresponde a",round(int(dolares*conversion)),"pesos"
