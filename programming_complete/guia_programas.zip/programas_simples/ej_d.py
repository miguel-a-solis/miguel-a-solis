nombre = raw_input("Ingrese nombre: ")
ciudad = raw_input("Zona residencia: ")
edad = int(raw_input("Edad: "))
print "El usuario se llama",nombre, "es de",ciudad,"y tiene",edad,"anhos"
