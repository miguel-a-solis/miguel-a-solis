mensaje = raw_input("Mensaje invertido: ")
print mensaje[::-1]

# Alternativa 1(requiere uso de ciclo while):
# (borrar '#' y comentar o borrar el codigo anterior)
#
#mensaje = raw_input("Mensaje invertido: ")
#resultado = ""
#posicion = len(mensaje)-1
#while posicion >= 0:
#    resultado = resultado + mensaje[posicion]
#    posicion = posicion - 1
#print resultado
#
# Alternativa 2(requiere uso de ciclo for):
# (borrar '#' y comentar o borrar los codigos anteriores)
#
#mensaje = raw_input("Mensaje invertido: ")
#resultado = ""
#for posicion in range(len(mensaje)-1,-1,-1):
#    resultado = resultado + mensaje[posicion]
#print resultado
