libras = float(raw_input("Ingrese libras: "))
conversion = 2.2046
kilos = libras/conversion
print "El equivalente es",round(kilos,2),"kilos"
