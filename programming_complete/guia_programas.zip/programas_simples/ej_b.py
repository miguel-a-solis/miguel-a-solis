from math import pi
r = float(raw_input("Ingrese radio: "))
p = 2*pi*r
a = pi*r**2
print "Su perimetro es",round(p,2)
print "Su area es",round(a,2)
