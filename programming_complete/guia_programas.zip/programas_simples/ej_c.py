nombre = raw_input("Ingrese nombre: ")
print "Hola",nombre
