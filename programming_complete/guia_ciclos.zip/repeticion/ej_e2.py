suma = 0
mayor_nota = 0
mayor_alumno = ""
cantidad_alumnos = int(raw_input("Ingrese cantidad de alumnos: "))
for alumno in range(1,cantidad_alumnos+1):
    nota = float(raw_input("Nota Alumno "+str(alumno)+": "))
    suma += nota
    if nota > mayor_nota:
        mayor_nota = nota
        mayor_alumno = alumno
promedio = suma/cantidad_alumnos
print "Promedio de curso fue de",round(promedio,3)
print "El Alumno",mayor_alumno,"obtuvo la mejor calificacion"
