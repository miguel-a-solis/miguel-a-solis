suma_positivos = 0
cuenta_positivos = 0
suma_negativos = 0
cuenta_negativos = 0
numero = ""
while numero != 0:
    numero = float(raw_input("Ingrese numero: "))
    if numero != 0:
        if numero > 0:
            suma_positivos += numero
            cuenta_positivos += 1
        else:
            suma_negativos += numero
            cuenta_negativos += 1
print "Promedio positivos:",suma_positivos/cuenta_positivos
print "Promedio negativos:",abs(suma_negativos)/cuenta_negativos
# Alternativa:
# (borrar '#' y comentar o borrar el codigo anterior)
#
suma_positivos = 0
cuenta_positivos = 0
suma_negativos = 0
cuenta_negativos = 0
while True:
    numero = float(raw_input("Ingrese numero: "))
    if numero == 0:
        break
    if numero > 0:
        suma_positivos += numero
        cuenta_positivos += 1
    else:
        suma_negativos += numero
        cuenta_negativos += 1
print "Promedio positivos:",suma_positivos/cuenta_positivos
print "Promedio negativos:",abs(suma_negativos)/cuenta_negativos
        
