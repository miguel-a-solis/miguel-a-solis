correcta = raw_input("Ingrese secuencia correcta de respuestas: ")
alumnos = int(raw_input("Ingrese cantidad de alumnos: "))
for cuenta_alumnos in range(1,alumnos+1):
    correctas = 0.0
    secuencia = raw_input("Alumno " + str(cuenta_alumnos) + ": ")
    for indice in range(len(secuencia)):
        if secuencia[indice] == correcta[indice]:
            correctas += 1
    print "Nota Alumno",cuenta_alumnos,":",int(round(100*correctas/len(correcta)))
