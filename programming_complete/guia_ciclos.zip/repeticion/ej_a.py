cuenta_benefactor = 1
mayor_monto = 0
mayor_benefactor = ""
total = 0
N = int(raw_input("Cantidad de benefactores: "))
M = int(raw_input("Ingrese monto a recaudar: "))
while cuenta_benefactor <= N and total < M:
    monto = int(raw_input("Benefactor " + str(cuenta_benefactor)+": "))
    total = total + monto
    if monto >= mayor_monto:
        mayor_monto = monto
        mayor_benefactor = cuenta_benefactor
    cuenta_benefactor = cuenta_benefactor + 1
print "Participaron",cuenta_benefactor-1,"y el monto recaudado fue de",total
print "El mayor monto fue de",mayor_monto,"por el benefactor",mayor_benefactor
