binario = raw_input("Ingrese secuencia binaria")
suma = 0
exponente = 0
secuencia_invertida = binario[::-1]
if int(binario[0]) == 0:
    signo = 1
else:
    signo = -1
for digito in secuencia_invertida[:len(binario)-1]:
    suma = suma + int(digito)*2**exponente
    exponente += 1
decimal = signo*suma
print "El equivalente decimal con signo es",decimal
