hora = 10
anterior = 0
mayor_alza = 0
while hora <= 20:
    actual = int(raw_input(str(hora)+" horas: "))
    if actual-anterior >= mayor_alza:
        mayor_alza = actual-anterior
    anterior = actual
    hora = hora + 1
print "La mayor alza fue de",mayor_alza,"personas"
